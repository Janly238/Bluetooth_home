/** Automatically generated file. DO NOT MODIFY */
package com.ThinBTClient.www;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}